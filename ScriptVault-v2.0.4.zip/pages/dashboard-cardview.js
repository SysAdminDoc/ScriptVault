// ScriptVault — Card View Module
// Provides an alternative card-based grid layout for the script list,
// with responsive columns, site favicons, status indicators, and animated
// toggle between table and card views. Persists preference in settings.

const CardView = (() => {
  'use strict';

  /* ------------------------------------------------------------------ */
  /*  Constants                                                          */
  /* ------------------------------------------------------------------ */

  const STORAGE_KEY = 'sv_viewMode';
  const DESCRIPTION_MAX = 120;
  const TRANSITION_MS = 300;

  /* ------------------------------------------------------------------ */
  /*  Internal state                                                     */
  /* ------------------------------------------------------------------ */

  let _container = null;
  let _cardGrid = null;
  let _styleEl = null;
  let _viewMode = 'table'; // 'table' | 'card'
  let _scripts = [];
  let _options = {};
  let _toggleBtn = null;
  let _ownsToggleBtn = false;
  let _toggleClickHandler = null;
  let _activeMenuId = null;
  let _tableContainer = null;

  /* ------------------------------------------------------------------ */
  /*  CSS                                                                */
  /* ------------------------------------------------------------------ */

  const STYLES = `
/* Card View Grid */
.cv-grid {
  display: grid;
  grid-template-columns: repeat(1, 1fr);
  gap: 16px;
  padding: 16px;
  opacity: 1;
  transition: opacity ${TRANSITION_MS}ms ease;
}
.cv-grid.cv-hidden { display: none; }
.cv-grid.cv-fade-out { opacity: 0; }

@media (min-width: 560px)  { .cv-grid { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 900px)  { .cv-grid { grid-template-columns: repeat(3, 1fr); } }
@media (min-width: 1280px) { .cv-grid { grid-template-columns: repeat(4, 1fr); } }

/* Card */
.cv-card {
  position: relative;
  background:
    radial-gradient(circle at top right, rgba(96, 165, 250, 0.08), transparent 34%),
    linear-gradient(180deg, rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.02)),
    var(--bg-row);
  border: 1px solid var(--panel-border-soft, rgba(148, 163, 184, 0.16));
  border-radius: 24px;
  padding: 18px;
  cursor: pointer;
  transition: transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease;
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-height: 188px;
  overflow: hidden;
  content-visibility: auto;
  contain-intrinsic-size: 240px;
  contain: layout style paint;
  box-shadow: var(--panel-sheen, inset 0 1px 0 rgba(255,255,255,0.08)), var(--panel-shadow, 0 18px 40px rgba(0,0,0,0.18));
}
.cv-card::before {
  content: '';
  position: absolute;
  inset: 0 0 auto 0;
  height: 2px;
  background: linear-gradient(90deg, rgba(96, 165, 250, 0), rgba(125, 211, 252, 0.65), rgba(96, 165, 250, 0));
  pointer-events: none;
}
.cv-card::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(255, 255, 255, 0.08), transparent 42%, transparent 62%, rgba(255,255,255,0.03));
  pointer-events: none;
}
.cv-card:hover {
  transform: translateY(-2px);
  box-shadow: var(--panel-sheen, inset 0 1px 0 rgba(255,255,255,0.08)), 0 24px 42px rgba(0,0,0,.24);
  border-color: rgba(96, 165, 250, 0.32);
}
.cv-grid[data-list-size="large"] .cv-card,
.cv-grid[data-list-size="huge"] .cv-card {
  transition: border-color 160ms ease, box-shadow 160ms ease, background 160ms ease;
}
.cv-grid[data-list-size="huge"] .cv-card:hover {
  transform: none;
}

/* Status borders */
.cv-card.cv-enabled  {
  border-left: 1px solid var(--panel-border-soft, rgba(148, 163, 184, 0.16));
  box-shadow: inset 0 0 0 1px rgba(52, 211, 153, 0.14), 0 18px 40px rgba(0,0,0,0.18);
}
.cv-card.cv-disabled {
  border-left: 1px solid var(--panel-border-soft, rgba(148, 163, 184, 0.16));
  opacity: 0.78;
}

/* Status dots */
.cv-status-dots {
  position: absolute;
  top: 14px;
  right: 14px;
  display: flex;
  gap: 5px;
  align-items: center;
  z-index: 1;
}
.cv-dot {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: inline-block;
  box-shadow: 0 0 0 4px rgba(15, 23, 42, 0.18);
}
.cv-dot-error  { background: var(--accent-red); }
.cv-dot-stale  { background: var(--accent-yellow); }
.cv-dot-budget { background: var(--accent-orange); }

/* Header row: icon + name */
.cv-header {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  min-width: 0;
  position: relative;
  z-index: 1;
}
.cv-name-stack {
  display: flex;
  flex-direction: column;
  gap: 5px;
  min-width: 0;
  flex: 1;
}
.cv-name-btn {
  appearance: none;
  background: none;
  border: none;
  padding: 0;
  margin: 0;
  text-align: left;
  color: var(--text-primary);
  font: inherit;
  min-width: 0;
  cursor: pointer;
}
.cv-name-btn:hover .cv-name,
.cv-name-btn:focus-visible .cv-name {
  color: var(--accent-blue);
}
.cv-name-btn:focus-visible {
  outline: 2px solid rgba(90, 140, 255, 0.45);
  outline-offset: 3px;
  border-radius: 8px;
}

/* Favicon / letter avatar */
.cv-icon {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  flex-shrink: 0;
  object-fit: contain;
  box-shadow: 0 12px 18px rgba(0,0,0,0.18);
}
.cv-icon-letter {
  width: 38px;
  height: 38px;
  border-radius: 10px;
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 16px;
  font-weight: 700;
  color: #fff;
  box-shadow: 0 12px 18px rgba(0,0,0,0.18);
}

.cv-name {
  font-size: 15px;
  font-weight: 700;
  color: var(--text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
  min-width: 0;
}
.cv-domain {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: fit-content;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--text-secondary);
  padding: 5px 9px;
  border-radius: 999px;
  background: rgba(90, 140, 255, 0.12);
  border: 1px solid rgba(90, 140, 255, 0.18);
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.06);
}

/* Meta row */
.cv-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 6px 12px;
  font-size: 11px;
  color: var(--text-secondary);
  font-variant-numeric: tabular-nums;
  position: relative;
  z-index: 1;
}
.cv-meta-item {
  display: flex;
  align-items: center;
  gap: 3px;
}
.cv-meta-label { color: var(--text-muted); }
.cv-meta-button {
  appearance: none;
  background: rgba(90, 140, 255, 0.08);
  border: 1px solid rgba(90, 140, 255, 0.15);
  color: var(--text-secondary);
  font: inherit;
  font-size: 11px;
  border-radius: 999px;
  padding: 5px 10px;
  cursor: pointer;
  transition: color 150ms ease, border-color 150ms ease, background 150ms ease, box-shadow 150ms ease;
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.05);
}
.cv-meta-button:hover,
.cv-meta-button:focus-visible {
  color: var(--text-primary);
  border-color: rgba(90, 140, 255, 0.45);
  background: rgba(90, 140, 255, 0.14);
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.08), 0 10px 18px rgba(59,130,246,0.14);
}
.cv-meta-button:focus-visible {
  outline: 2px solid rgba(90, 140, 255, 0.35);
  outline-offset: 2px;
}

/* Description */
.cv-desc {
  font-size: 12px;
  color: var(--text-secondary);
  line-height: 1.6;
  overflow: hidden;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  position: relative;
  z-index: 1;
}

/* Performance badge */
.cv-perf {
  display: inline-block;
  font-size: 10px;
  font-weight: 700;
  padding: 4px 8px;
  border-radius: 999px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
}
.cv-perf.fast   { background: rgba(74,222,128,.15); color: var(--accent-green); }
.cv-perf.medium { background: rgba(251,191,36,.15); color: var(--accent-yellow); }
.cv-perf.slow   { background: rgba(248,113,113,.15); color: var(--accent-red); }

/* Footer: toggle + menu */
.cv-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: auto;
  padding-top: 12px;
  border-top: 1px solid rgba(127, 127, 127, 0.14);
  position: relative;
  z-index: 1;
}

@media (prefers-reduced-motion: reduce) {
  .cv-grid,
  .cv-card,
  .cv-meta-button,
  .cv-view-toggle {
    transition: none;
  }
  .cv-card:hover {
    transform: none;
  }
}

/* Toggle switch (reuses dashboard toggle) */
.cv-toggle {
  position: relative;
  width: 36px;
  height: 20px;
  cursor: pointer;
}
.cv-toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
.cv-toggle-slider {
  position: absolute;
  inset: 0;
  background: var(--toggle-off);
  border-radius: 20px;
  transition: background 200ms;
}
.cv-toggle-slider::before {
  content: '';
  position: absolute;
  width: 16px;
  height: 16px;
  left: 2px;
  bottom: 2px;
  background: #fff;
  border-radius: 50%;
  transition: transform 200ms;
}
.cv-toggle input:checked + .cv-toggle-slider { background: var(--toggle-on); }
.cv-toggle input:checked + .cv-toggle-slider::before { transform: translateX(16px); }

/* Three-dot menu */
.cv-menu-btn {
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(127,127,127,0.14);
  color: var(--text-secondary);
  cursor: pointer;
  padding: 6px 8px;
  border-radius: 10px;
  font-size: 16px;
  line-height: 1;
  letter-spacing: 2px;
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.05);
}
.cv-menu-btn:hover {
  background:
    linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.02)),
    var(--bg-row-hover);
  color: var(--text-primary);
  border-color: rgba(96,165,250,0.24);
}

.cv-menu {
  position: absolute;
  right: 16px;
  bottom: 50px;
  background:
    linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.02)),
    var(--bg-header);
  border: 1px solid var(--panel-border-strong, rgba(148,163,184,0.28));
  border-radius: 16px;
  padding: 6px;
  min-width: 160px;
  z-index: 1000;
  box-shadow: var(--panel-sheen, inset 0 1px 0 rgba(255,255,255,0.08)), 0 24px 40px rgba(0,0,0,.28);
  -webkit-backdrop-filter: blur(14px);
  backdrop-filter: blur(14px);
}
.cv-menu.cv-hidden { display: none; }
.cv-menu-item {
  display: block;
  width: 100%;
  padding: 10px 12px;
  background: none;
  border: none;
  color: var(--text-primary);
  font-size: 12px;
  border-radius: 10px;
  text-align: left;
  cursor: pointer;
  white-space: nowrap;
}
.cv-menu-item:hover { background: rgba(255,255,255,0.06); }
.cv-menu-item.danger { color: var(--accent-red); }

.cv-empty {
  display: grid;
  place-items: center;
  min-height: 240px;
  padding: 40px 28px;
  border: 1px solid var(--panel-border-soft, rgba(148, 163, 184, 0.16));
  border-radius: 24px;
  background:
    radial-gradient(circle at top, rgba(90, 140, 255, 0.16), transparent 58%),
    linear-gradient(180deg, rgba(255, 255, 255, 0.08), rgba(255, 255, 255, 0.02));
  text-align: center;
  box-shadow: var(--panel-sheen, inset 0 1px 0 rgba(255,255,255,0.08)), var(--panel-shadow, 0 18px 40px rgba(0,0,0,0.18));
}
.cv-empty h3 {
  margin: 0 0 8px;
  font-size: 18px;
  color: var(--text-primary);
}
.cv-empty p {
  margin: 0;
  max-width: 440px;
  font-size: 13px;
  line-height: 1.55;
  color: var(--text-secondary);
}

/* View toggle button */
.cv-view-toggle {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background:
    linear-gradient(180deg, rgba(255,255,255,0.08), rgba(255,255,255,0.02)),
    var(--bg-input);
  border: 1px solid var(--panel-border-soft, rgba(148, 163, 184, 0.16));
  border-radius: 14px;
  padding: 8px 12px;
  color: var(--text-secondary);
  font-size: 12px;
  cursor: pointer;
  transition: color 150ms, border-color 150ms, background 150ms, box-shadow 150ms;
  box-shadow: var(--panel-sheen, inset 0 1px 0 rgba(255,255,255,0.08)), 0 14px 24px rgba(0,0,0,0.14);
}
.cv-view-toggle:hover {
  color: var(--text-primary);
  border-color: rgba(96,165,250,0.28);
  box-shadow: var(--panel-sheen, inset 0 1px 0 rgba(255,255,255,0.08)), 0 18px 30px rgba(0,0,0,0.2);
}
.cv-view-toggle svg {
  width: 16px;
  height: 16px;
  stroke: currentColor;
  fill: none;
  stroke-width: 2;
}

/* Table fade for transition */
.cv-table-fade-out {
  opacity: 0 !important;
  transition: opacity ${TRANSITION_MS}ms ease !important;
}

@media (max-width: 768px) {
  .cv-grid {
    gap: 14px;
    padding: 14px;
  }

  .cv-card {
    border-radius: 20px;
    padding: 16px;
  }
}
`;

  /* ------------------------------------------------------------------ */
  /*  Helpers                                                            */
  /* ------------------------------------------------------------------ */

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function hashStr(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    }
    return Math.abs(h);
  }

  function nameToColor(name) {
    const hue = hashStr(name || 'Script') % 360;
    return `hsl(${hue}, 55%, 45%)`;
  }

  function truncate(str, max) {
    if (!str || str.length <= max) return str || '';
    return str.slice(0, max).trimEnd() + '\u2026';
  }

  function extractFirstDomain(matches) {
    if (!matches || !matches.length) return null;
    for (const m of matches) {
      try {
        const cleaned = m.replace(/^\*:\/\//, 'https://').replace(/\/\*$/, '/');
        const url = new URL(cleaned);
        if (url.hostname && url.hostname !== '*') {
          return url.hostname.replace(/^\*\./, '');
        }
      } catch { /* skip */ }
    }
    return null;
  }

  function formatRelativeTime(ts) {
    if (!ts) return '-';
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    if (days < 30) return `${days}d ago`;
    const months = Math.floor(days / 30);
    return `${months}mo ago`;
  }

  function getCardListSize(count) {
    if (count <= 0) return 'empty';
    if (count >= 80) return 'huge';
    if (count >= 36) return 'large';
    if (count >= 12) return 'medium';
    return 'small';
  }

  function buildEmptyState() {
    const empty = document.createElement('div');
    const hasScripts = typeof _options.hasScripts === 'function' ? _options.hasScripts() : _scripts.length > 0;
    empty.className = 'cv-empty';
    empty.innerHTML = hasScripts
      ? '<div><h3>Nothing matches this view</h3><p>Adjust the current search or filter to bring scripts back into focus.</p></div>'
      : '<div><h3>No scripts yet</h3><p>Create or import a script to start building out the vault.</p></div>';
    return empty;
  }

  /* ------------------------------------------------------------------ */
  /*  Style injection                                                    */
  /* ------------------------------------------------------------------ */

  function injectStyles() {
    if (_styleEl) return;
    _styleEl = document.createElement('style');
    _styleEl.id = 'sv-cardview-styles';
    _styleEl.textContent = STYLES;
    document.head.appendChild(_styleEl);
  }

  function removeStyles() {
    if (_styleEl) {
      _styleEl.remove();
      _styleEl = null;
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Persistence                                                        */
  /* ------------------------------------------------------------------ */

  function loadViewMode() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored === 'table' || stored === 'card') return stored;
    } catch { /* ignore */ }
    return 'table';
  }

  function saveViewMode(mode) {
    try { localStorage.setItem(STORAGE_KEY, mode); } catch { /* ignore */ }
  }

  function createCardIconHtml(name, iconUrl) {
    const initial = escapeHtml(name.charAt(0).toUpperCase());
    const background = nameToColor(name);
    if (iconUrl) {
      return `<img class="cv-icon" src="${escapeHtml(iconUrl)}" alt="" loading="lazy" data-favicon-fallback="true">
        <span class="cv-icon-letter" hidden style="background:${background}">${initial}</span>`;
    }
    return `<span class="cv-icon-letter" style="background:${background}">${initial}</span>`;
  }

  function revealCardIconFallback(iconEl) {
    if (!(iconEl instanceof HTMLImageElement)) return;
    iconEl.hidden = true;
    const fallback = iconEl.nextElementSibling;
    if (fallback instanceof HTMLElement) {
      fallback.hidden = false;
    }
  }

  function invokeCardAction(callback, ...args) {
    if (typeof callback !== 'function') return;
    try {
      const result = callback(...args);
      if (result && typeof result.catch === 'function') {
        result.catch(error => console.error('[CardView] Action failed:', error));
      }
    } catch (error) {
      console.error('[CardView] Action failed:', error);
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Card rendering                                                     */
  /* ------------------------------------------------------------------ */

  function buildCard(script) {
    const card = document.createElement('article');
    const cardTitleId = `cv-title-${script.id}`;
    card.className = `cv-card ${script.enabled !== false ? 'cv-enabled' : 'cv-disabled'}`;
    card.dataset.scriptId = script.id;
    card.setAttribute('aria-labelledby', cardTitleId);

    const name = script.metadata?.name || 'Unnamed Script';
    const version = script.metadata?.version || '1.0';
    const author = script.metadata?.author || '';
    const desc = script.metadata?.description || '';
    const enabled = script.enabled !== false;
    const matches = [...(script.metadata?.match || []), ...(script.metadata?.include || [])];
    const domain = extractFirstDomain(matches);
    const iconUrl = script.metadata?.icon || script.metadata?.iconURL;
    const stats = script.stats;
    const hasErrors = stats?.errors > 0;
    const daysSinceUpdate = script.updatedAt ? Math.floor((Date.now() - script.updatedAt) / 86400000) : 0;
    const isStale = daysSinceUpdate > 180 && (script.metadata?.updateURL || script.metadata?.downloadURL);
    const perfBudget = script.settings?.perfBudget || 200;
    const overBudget = stats?.avgTime > perfBudget && stats?.runs > 2;

    // Status dots
    const dots = [];
    if (hasErrors)   dots.push('<span class="cv-dot cv-dot-error" title="Has errors"></span>');
    if (isStale)     dots.push('<span class="cv-dot cv-dot-stale" title="Stale script"></span>');
    if (overBudget)  dots.push('<span class="cv-dot cv-dot-budget" title="Over perf budget"></span>');

    const iconHtml = createCardIconHtml(name, iconUrl);

    // Perf badge
    let perfHtml = '';
    if (stats && stats.runs > 0 && stats.avgTime != null) {
      const cls = stats.avgTime < 50 ? 'fast' : stats.avgTime < 200 ? 'medium' : 'slow';
      const label = stats.avgTime < 50 ? 'Fast' : stats.avgTime < 200 ? 'OK' : 'Slow';
      perfHtml = `<span class="cv-perf ${cls}" title="${stats.avgTime}ms avg">${label}</span>`;
    }

    card.innerHTML = `
      <div class="cv-status-dots">${dots.join('')}</div>
      <div class="cv-header">
        ${iconHtml}
        <div class="cv-name-stack">
          <button type="button" class="cv-name-btn" data-open-id="${script.id}" aria-label="Open ${escapeHtml(name)} in the editor">
            <span class="cv-name" id="${cardTitleId}" title="${escapeHtml(name)}">${escapeHtml(name)}</span>
          </button>
          ${domain ? `<span class="cv-domain" title="${escapeHtml(domain)}">${escapeHtml(domain)}</span>` : ''}
        </div>
      </div>
      ${desc ? `<div class="cv-desc" title="${escapeHtml(desc)}">${escapeHtml(truncate(desc, DESCRIPTION_MAX))}</div>` : ''}
      <div class="cv-meta">
        <span class="cv-meta-item"><span class="cv-meta-label">v</span>${escapeHtml(version)}</span>
        ${author ? `<span class="cv-meta-item"><span class="cv-meta-label">by</span>${escapeHtml(author)}</span>` : ''}
        <span class="cv-meta-item"><span class="cv-meta-label">matches</span>${matches.length}</span>
        <button type="button" class="cv-meta-button" data-update-id="${script.id}" aria-label="Check for updates for ${escapeHtml(name)}" title="Check for updates">${formatRelativeTime(script.updatedAt)}</button>
        ${perfHtml}
      </div>
      <div class="cv-footer">
        <label class="cv-toggle" title="${enabled ? 'Enabled' : 'Disabled'}">
          <input type="checkbox" ${enabled ? 'checked' : ''} data-toggle-id="${script.id}" aria-label="${enabled ? 'Disable' : 'Enable'} ${escapeHtml(name)}">
          <span class="cv-toggle-slider"></span>
        </label>
        <button type="button" class="cv-menu-btn" data-menu-id="${script.id}" title="Actions" aria-label="Script actions for ${escapeHtml(name)}" aria-haspopup="menu" aria-expanded="false">\u22EF</button>
        <div class="cv-menu cv-hidden" data-menu-for="${script.id}" role="menu" aria-label="Actions for ${escapeHtml(name)}">
          <button type="button" class="cv-menu-item" data-action="edit" data-id="${script.id}">Edit</button>
          <button type="button" class="cv-menu-item" data-action="toggle" data-id="${script.id}">${enabled ? 'Disable' : 'Enable'}</button>
          <button type="button" class="cv-menu-item" data-action="update" data-id="${script.id}">Check Update</button>
          <button type="button" class="cv-menu-item" data-action="export" data-id="${script.id}">Export</button>
          <button type="button" class="cv-menu-item danger" data-action="delete" data-id="${script.id}">Delete</button>
        </div>
      </div>
    `;

    const icon = card.querySelector('.cv-icon[data-favicon-fallback="true"]');
    icon?.addEventListener('error', () => revealCardIconFallback(icon));

    // -- Event listeners --

    // Click card body -> open editor
    card.addEventListener('click', (e) => {
      if (e.target.closest('.cv-toggle') || e.target.closest('.cv-menu-btn') || e.target.closest('.cv-menu')) return;
      invokeCardAction(_options.onEdit, script.id);
    });

    const openBtn = card.querySelector(`[data-open-id="${script.id}"]`);
    openBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      invokeCardAction(_options.onEdit, script.id);
    });

    const updateBtn = card.querySelector(`[data-update-id="${script.id}"]`);
    updateBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      invokeCardAction(_options.onUpdate, script.id, { triggerEl: updateBtn });
    });

    // Toggle switch
    const toggle = card.querySelector(`[data-toggle-id="${script.id}"]`);
    toggle?.addEventListener('change', (e) => {
      e.stopPropagation();
      invokeCardAction(_options.onToggle, script.id, e.target.checked, { control: toggle });
    });
    toggle?.addEventListener('click', (e) => e.stopPropagation());

    // Three-dot menu
    const menuBtn = card.querySelector(`[data-menu-id="${script.id}"]`);
    menuBtn?.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleCardMenu(script.id);
    });
    const menu = card.querySelector(`[data-menu-for="${script.id}"]`);
    menu?.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        closeAllMenus();
        menuBtn?.focus();
      }
    });

    // Menu actions
    card.querySelectorAll('.cv-menu-item').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        closeAllMenus();
        const action = btn.dataset.action;
        const id = btn.dataset.id;
        switch (action) {
          case 'edit':   invokeCardAction(_options.onEdit, id); break;
          case 'toggle': invokeCardAction(_options.onToggle, id, !enabled, { control: btn }); break;
          case 'update': invokeCardAction(_options.onUpdate, id, { triggerEl: btn }); break;
          case 'export': invokeCardAction(_options.onExport, id, { triggerEl: btn }); break;
          case 'delete': invokeCardAction(_options.onDelete, id, { triggerEl: btn }); break;
        }
      });
    });

    return card;
  }

  /* ------------------------------------------------------------------ */
  /*  Menu management                                                    */
  /* ------------------------------------------------------------------ */

  function toggleCardMenu(id) {
    const wasOpen = _activeMenuId === id;
    closeAllMenus();
    if (wasOpen) return;
    const menu = _cardGrid?.querySelector(`[data-menu-for="${id}"]`);
    const menuBtn = _cardGrid?.querySelector(`[data-menu-id="${id}"]`);
    if (menu) {
      menu.classList.remove('cv-hidden');
      _activeMenuId = id;
      menuBtn?.setAttribute('aria-expanded', 'true');
    }
  }

  function closeAllMenus() {
    _activeMenuId = null;
    _cardGrid?.querySelectorAll('.cv-menu').forEach(m => m.classList.add('cv-hidden'));
    _cardGrid?.querySelectorAll('.cv-menu-btn').forEach(btn => btn.setAttribute('aria-expanded', 'false'));
  }

  /* ------------------------------------------------------------------ */
  /*  View toggle button                                                 */
  /* ------------------------------------------------------------------ */

  function createToggleButton() {
    const btn = document.createElement('button');
    btn.className = 'cv-view-toggle';
    updateToggleIcon(btn);
    return btn;
  }

  function getToggleSvg(mode) {
    if (mode === 'table') {
      return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>';
    }
    return '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>';
  }

  function updateToggleIcon(btn) {
    if (!btn) return;
    const nextMode = _viewMode === 'table' ? 'card' : 'table';
    const compact = btn.id === 'btnViewToggle' || btn.classList.contains('compact');
    const label = nextMode === 'card' ? 'Switch to card view' : 'Switch to table view';
    btn.title = label;
    btn.setAttribute('aria-label', label);
    btn.setAttribute('aria-pressed', _viewMode === 'card' ? 'true' : 'false');
    btn.innerHTML = compact ? getToggleSvg(nextMode) : `${getToggleSvg(nextMode)} ${nextMode === 'card' ? 'Cards' : 'Table'}`;
  }

  /* ------------------------------------------------------------------ */
  /*  View switching                                                     */
  /* ------------------------------------------------------------------ */

  function syncLayout() {
    const showCards = _viewMode === 'card';
    if (_tableContainer) {
      _tableContainer.style.display = showCards ? 'none' : '';
    }
    if (_container) {
      _container.style.display = showCards ? '' : 'none';
    }
    if (_cardGrid) {
      _cardGrid.classList.toggle('cv-hidden', !showCards);
      _cardGrid.classList.remove('cv-fade-out');
    }
    updateToggleIcon(_toggleBtn);
  }

  function applyViewMode(mode, animate = true) {
    _viewMode = mode;
    saveViewMode(mode);
    if (_cardGrid && animate && mode === 'card') {
      _cardGrid.classList.add('cv-fade-out');
      syncLayout();
      requestAnimationFrame(() => _cardGrid?.classList.remove('cv-fade-out'));
      return;
    }
    syncLayout();
  }

  /* ------------------------------------------------------------------ */
  /*  Global click handler (close menus on outside click)                */
  /* ------------------------------------------------------------------ */

  function onDocumentClick(e) {
    if (_activeMenuId && !e.target.closest('.cv-menu-btn') && !e.target.closest('.cv-menu')) {
      closeAllMenus();
    }
  }

  /* ------------------------------------------------------------------ */
  /*  Public API                                                         */
  /* ------------------------------------------------------------------ */

  const api = {

    /**
     * Initialize the card view module.
     * @param {HTMLElement} containerEl - The parent element containing the script table.
     * @param {Object} options
     * @param {Function} options.onEdit     - Called with scriptId when edit requested.
     * @param {Function} options.onToggle   - Called with (scriptId, enabled).
     * @param {Function} options.onUpdate   - Called with scriptId.
     * @param {Function} options.onExport   - Called with scriptId.
     * @param {Function} options.onDelete   - Called with scriptId.
     * @param {HTMLElement} [options.tableContainer] - The table wrapper to hide in card mode.
     * @param {HTMLElement} [options.toggleButton] - Existing toggle button to bind.
     * @param {HTMLElement} [options.toggleTarget] - Element to append the view toggle button into.
     */
    init(containerEl, options = {}) {
      if (!containerEl) return;
      _container = containerEl;
      _options = options;
      _tableContainer = options.tableContainer || null;

      injectStyles();

      // Load persisted view mode
      _viewMode = loadViewMode();

      // Create card grid container
      _cardGrid = document.createElement('div');
      _cardGrid.className = 'cv-grid cv-hidden';
      _cardGrid.setAttribute('role', 'list');
      _cardGrid.setAttribute('aria-label', 'Script cards');
      _container.appendChild(_cardGrid);

      _toggleBtn = options.toggleButton || null;
      _ownsToggleBtn = !_toggleBtn;
      if (!_toggleBtn) {
        _toggleBtn = createToggleButton();
      }
      updateToggleIcon(_toggleBtn);
      _toggleClickHandler = () => {
        api.setViewMode(_viewMode === 'table' ? 'card' : 'table');
      };
      _toggleBtn.addEventListener('click', _toggleClickHandler);
      if (_ownsToggleBtn && options.toggleTarget) {
        options.toggleTarget.appendChild(_toggleBtn);
      }

      // Listen for outside clicks to close menus
      document.addEventListener('click', onDocumentClick);
      syncLayout();
    },

    /**
     * Render or re-render script cards from the provided list.
     * @param {Array} scripts - Array of script objects.
     */
    render(scripts) {
      _scripts = scripts || [];
      if (!_cardGrid) return;

      _cardGrid.innerHTML = '';
      _cardGrid.dataset.listSize = getCardListSize(_scripts.length);
      closeAllMenus();

      if (_scripts.length === 0) {
        _cardGrid.appendChild(buildEmptyState());
      } else {
        const fragment = document.createDocumentFragment();
        for (const script of _scripts) {
          const card = buildCard(script);
          card.setAttribute('role', 'listitem');
          fragment.appendChild(card);
        }
        _cardGrid.appendChild(fragment);
      }

      syncLayout();
    },

    /**
     * Switch between table and card view.
     * @param {'table'|'card'} mode
     */
    setViewMode(mode) {
      if (mode !== 'table' && mode !== 'card') return;
      if (mode === _viewMode) return;
      applyViewMode(mode, true);
    },

    /**
     * Get the current view mode.
     * @returns {'table'|'card'}
     */
    getViewMode() {
      return _viewMode;
    },

    /**
     * Clean up: remove styles, grid, listeners.
     */
    destroy() {
      document.removeEventListener('click', onDocumentClick);
      removeStyles();
      if (_toggleBtn && _toggleClickHandler) {
        _toggleBtn.removeEventListener('click', _toggleClickHandler);
      }
      if (_cardGrid) {
        _cardGrid.remove();
        _cardGrid = null;
      }
      if (_toggleBtn && _ownsToggleBtn) {
        _toggleBtn.remove();
      }
      _toggleBtn = null;
      _toggleClickHandler = null;
      _ownsToggleBtn = false;
      _container = null;
      _tableContainer = null;
      _scripts = [];
      _options = {};
      _activeMenuId = null;
      _viewMode = 'table';
    }
  };

  return api;
})();
